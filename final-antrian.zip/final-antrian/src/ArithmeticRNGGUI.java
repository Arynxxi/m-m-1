import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ArithmeticRNGGUI extends JFrame implements ActionListener {
    private JLabel label;
    private JButton generateButton;
    private JTextArea outputTextArea;
    private int Zn, m, a, c;

    public ArithmeticRNGGUI() {
        // Initialize the parameters for the arithmetic RNG
        Zn = 1341;
        m = 128;
        a = 19;
        c = 237;

        // Create GUI components
        label = new JLabel("Generated Random Numbers:");
        generateButton = new JButton("Generate");
        generateButton.addActionListener(this);
        outputTextArea = new JTextArea(10, 20);
        outputTextArea.setEditable(false);

        // Set up the GUI layout
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        panel.add(label);
        panel.add(outputTextArea);
        panel.add(generateButton);

        setTitle("Arithmetic Random Number Generator");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());
        add(panel);
        pack();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == generateButton) {
            // Generate and display 10 random numbers using the Arithmetic RNG
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 10; i++) {
                Zn = (a * Zn + c) % m;
                sb.append(Zn).append("\n");
            }
            outputTextArea.setText(sb.toString());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ArithmeticRNGGUI().setVisible(true);
        });
    }
}
