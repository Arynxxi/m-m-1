import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

public class JTextFieldToJTableWithRemainderExample extends JFrame {
    private JTextField dividendField, divisorField;
    private JTable dataTable;
    private DefaultTableModel tableModel;

    public JTextFieldToJTableWithRemainderExample() {
        JLabel dividendLabel = new JLabel("Dividend:");
        JLabel divisorLabel = new JLabel("Divisor:");

        dividendField = new JTextField(10);
        divisorField = new JTextField(10);

        JButton calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateAndAddToTable();
            }
        });

        Vector<String> columnNames = new Vector<>();
        columnNames.add("Dividend");
        columnNames.add("Divisor");
        columnNames.add("Quotient");
        columnNames.add("Remainder");

        Vector<Vector<Object>> data = new Vector<>();

        tableModel = new DefaultTableModel(data, columnNames);
        dataTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(dataTable);

        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        inputPanel.add(dividendLabel);
        inputPanel.add(dividendField);
        inputPanel.add(divisorLabel);
        inputPanel.add(divisorField);
        inputPanel.add(calculateButton);

        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setTitle("JTextField to JTable with Remainder Example");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void calculateAndAddToTable() {
        try {
            int dividend = Integer.parseInt(dividendField.getText());
            int divisor = Integer.parseInt(divisorField.getText());

            int quotient = dividend / divisor;
            int remainder = dividend % divisor;

            Vector<Object> rowData = new Vector<>();
            rowData.add(dividend);
            rowData.add(divisor);
            rowData.add(quotient);
            rowData.add(remainder);

            tableModel.addRow(rowData);

            // Clear text fields after adding data to the table
            dividendField.setText("");
            divisorField.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid integers.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new JTextFieldToJTableWithRemainderExample();
            }
        });
    }
}
