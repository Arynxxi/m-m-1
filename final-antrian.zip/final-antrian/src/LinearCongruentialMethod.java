public class LinearCongruentialMethod {
    private int a, m, c, Xn, seed;

    public LinearCongruentialMethod() {
        this.a = a;
        this.m = m;
        this.c = c;
        Xn = seed;
    }

    public int getNextRandomNumber() {
        Xn = (a * Xn + c) % m;
        return Xn;
    }

    public static void main(String[] args) {
        int a = 48271; // Multiplier
        int m = 2147483647; // Modulus (2^31 - 1)
        int c = 31; // Increment
        int seed = 123456789; // Initial seed

        LinearCongruentialMethod rng = new LinearCongruentialMethod();

        // Generate and print the first 10 random numbers
        for (int i = 0; i < 10; i++) {
            int random = rng.getNextRandomNumber();
            System.out.println(random);
        }
    }
}
