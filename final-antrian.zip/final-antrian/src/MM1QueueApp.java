import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

public class MM1QueueApp extends JFrame {
    private JTextField arrivalRateField;
    private JTextField serviceRateField;
    private JTextField introTimeField;
    private JTextField fromTimeField;
    private JButton calculateButton;
    private JTable resultTable;

    public MM1QueueApp() {
        setTitle("M/M/1 Queue Calculator");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(6, 2));

        JLabel arrivalRateLabel = new JLabel("Arrival Rate (λ):");
        arrivalRateField = new JTextField();
        JLabel serviceRateLabel = new JLabel("Service Rate (µ):");
        serviceRateField = new JTextField();
        JLabel introTimeLabel = new JLabel("Intro Time (Z):");
        introTimeField = new JTextField();
        JLabel fromTimeLabel = new JLabel("From Time (R):");
        fromTimeField = new JTextField();

        calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateAndShowResult();
            }
        });

        String[] columnNames = {"IAT", "Arrival Time", "Service Time", "Intro Time", "From Time", "Queueing Time", "SP Idle Time", "System Process Time"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        resultTable = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(resultTable);

        add(arrivalRateLabel);
        add(arrivalRateField);
        add(serviceRateLabel);
        add(serviceRateField);
        add(introTimeLabel);
        add(introTimeField);
        add(fromTimeLabel);
        add(fromTimeField);
        add(calculateButton);
        add(new JLabel()); // Empty cell
        add(scrollPane); // Table view

        pack();
        setLocationRelativeTo(null);
    }

    private void calculateAndShowResult() {
        try {
            double arrivalRate = Double.parseDouble(arrivalRateField.getText());
            double serviceRate = Double.parseDouble(serviceRateField.getText());
            double introTime = Double.parseDouble(introTimeField.getText());
            double fromTime = Double.parseDouble(fromTimeField.getText());

            DefaultTableModel model = (DefaultTableModel) resultTable.getModel();
            model.setRowCount(0); // Clear previous data

            DecimalFormat decimalFormat = new DecimalFormat("0.00");

            double currentTime = fromTime;
            double prevArrivalTime = 0;
            double prevFinishTime = fromTime;

            while (currentTime <= introTime) {
                double interArrivalTime = 1 / arrivalRate;
                double arrivalTime = prevArrivalTime + interArrivalTime;
                double serviceTime = 1 / serviceRate;
                double queueingTime = Math.max(0, prevFinishTime - arrivalTime);
                double spIdleTime = Math.max(0, arrivalTime - prevFinishTime);
                double systemProcessTime = serviceTime + queueingTime;

                Object[] rowData = {
                        decimalFormat.format(interArrivalTime),
                        decimalFormat.format(arrivalTime),
                        decimalFormat.format(serviceTime),
                        decimalFormat.format(introTime),
                        decimalFormat.format(fromTime),
                        decimalFormat.format(queueingTime),
                        decimalFormat.format(spIdleTime),
                        decimalFormat.format(systemProcessTime)
                };

                model.addRow(rowData);

                prevArrivalTime = arrivalTime;
                prevFinishTime = arrivalTime + systemProcessTime;
                currentTime = Math.min(prevFinishTime, introTime);
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid input");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MM1QueueApp().setVisible(true);
            }
        });
    }
}
