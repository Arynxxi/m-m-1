import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MM1SimulationGUI extends JFrame {
    private JTextField jumlahCostumerField, arrivalRateField, serviceRateField, simulationTimeField;
    private JTable resultTable;
    private DefaultTableModel tableModel;

    public MM1SimulationGUI() {
        JLabel jumlahCostumerLabel = new JLabel("Jumlah Costumer");
        JLabel arrivalRateLabel = new JLabel("Arrival Rate (λ):");
        JLabel serviceRateLabel = new JLabel("Service Rate (μ):");
        JLabel simulationTimeLabel = new JLabel("Simulation Time:");

        jumlahCostumerField = new JTextField(10);
        arrivalRateField = new JTextField(10);
        serviceRateField = new JTextField(10);
        simulationTimeField = new JTextField(10);

        JButton simulateButton = new JButton("Simulate");
        simulateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                simulateMM1();
            }
        });

        Object[] columnNames = {"Customer", "Arrival Time", "Service Time", "Start Time", "Departure Time", "Waiting Time"};
        Object[][] data = {};

        tableModel = new DefaultTableModel(data, columnNames);
        resultTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(resultTable);

        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        inputPanel.add(jumlahCostumerLabel);
        inputPanel.add(jumlahCostumerField);
        inputPanel.add(arrivalRateLabel);
        inputPanel.add(arrivalRateField);
        inputPanel.add(serviceRateLabel);
        inputPanel.add(serviceRateField);
        inputPanel.add(simulationTimeLabel);
        inputPanel.add(simulationTimeField);
        inputPanel.add(simulateButton);

        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setTitle("M/M/1 Queue Simulation");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void simulateMM1() {
        try {
            double arrivalRate = Double.parseDouble(arrivalRateField.getText());
            double serviceRate = Double.parseDouble(serviceRateField.getText());
            double simulationTime = Double.parseDouble(simulationTimeField.getText());

            double currentTime = 0.0;
            int customerNum = 1;

            while (currentTime < simulationTime) {
                double arrivalTime = currentTime + exponentialRandom(arrivalRate);
                double serviceTime = exponentialRandom(serviceRate);
                double startTime = Math.max(arrivalTime, currentTime);
                double departureTime = startTime + serviceTime;
                double waitingTime = startTime - arrivalTime;

                Object[] rowData = {customerNum, arrivalTime, serviceTime, startTime, departureTime, waitingTime};
                tableModel.addRow(rowData);

                customerNum++;
                currentTime = departureTime;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numbers.");
        }
    }

    // Generate a random number from exponential distribution with rate parameter lambda
    private double exponentialRandom(double lambda) {
        return -Math.log(1 - Math.random()) / lambda;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MM1SimulationGUI();
            }
        });
    }
}
