public class Main {

    private Integer no, z, r, iat, arrivalTime, servicetime, introTime, fromTime, queueing, sp, systemProcessTime;

    public Main (Integer no, Integer z, Integer r, Integer iat, Integer arrivalTime, Integer servicetime, Integer introTime, Integer fromTime, Integer queueing, Integer sp, Integer systemProcessTime) {

        this.no = no;
        this.z = z;
        this.r = r;
        this.iat = iat;
        this.arrivalTime = arrivalTime;
        this.servicetime = servicetime;
        this.introTime = introTime;
        this.fromTime = fromTime;
        this.queueing = queueing;
        this.sp = sp;
        this.systemProcessTime = systemProcessTime;

    }

    public Integer getNo() {
        return no;
    }

    public void setNo(Integer no) {
        this.no = no;
    }

    public Integer getZ() {
        return z;
    }

    public void setZ(Integer z) {
        this.z = z;
    }

    public Integer getR() {
        return r;
    }

    public void setR(Integer r) {
        this.r = r;
    }

    public Integer getIat() {
        return iat;
    }

    public void setIat(Integer iat) {
        this.iat = iat;
    }

    public Integer getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(Integer arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public Integer getServicetime() {
        return servicetime;
    }

    public void setServicetime(Integer servicetime) {
        this.servicetime = servicetime;
    }

    public Integer getIntroTime() {
        return introTime;
    }

    public void setIntroTime(Integer introTime) {
        this.introTime = introTime;
    }

    public Integer getFromTime() {
        return fromTime;
    }

    public void setFromTime(Integer fromTime) {
        this.fromTime = fromTime;
    }

    public Integer getQueueing() {
        return queueing;
    }

    public void setQueueing(Integer queueing) {
        this.queueing = queueing;
    }

    public Integer getSp() {
        return sp;
    }

    public void setSp(Integer sp) {
        this.sp = sp;
    }

    public Integer getSystemProcessTime() {
        return systemProcessTime;
    }

    public void setSystemProcessTime(Integer systemProcessTime) {
        this.systemProcessTime = systemProcessTime;
    }


}