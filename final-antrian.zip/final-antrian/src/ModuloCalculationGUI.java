import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModuloCalculationGUI extends JFrame {

    private JTable table;
    private DefaultTableModel tableModel;
    private JButton startButton;

    public ModuloCalculationGUI() {
        setTitle("Modulo Calculation");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        tableModel = new DefaultTableModel(new Object[]{"Iteration", "Result"}, 0);
        table = new JTable(tableModel);

        startButton = new JButton("Start Calculation");
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performModuloCalculation();
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);

        JPanel panel = new JPanel();
        panel.add(scrollPane);
        panel.add(startButton);

        add(panel);
    }

    private void performModuloCalculation() {
        int B3 = 2; // Ganti dengan nilai B3 yang diinginkan
        int B5 = 5; // Ganti dengan nilai B5 yang diinginkan
        int B4 = 7; // Ganti dengan nilai B4 yang diinginkan

        int result = B5;
        int rowCount = 10; // Jumlah perulangan

        for (int i = 1; i <= rowCount; i++) {
            result = (B3 * result + B5) % B4;
            tableModel.addRow(new Object[]{i, result});
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                ModuloCalculationGUI gui = new ModuloCalculationGUI();
                gui.setVisible(true);
            }
        });
    }
}
