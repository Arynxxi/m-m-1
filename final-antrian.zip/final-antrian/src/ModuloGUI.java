import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModuloGUI extends JFrame {

    private JTable table;
    private DefaultTableModel tableModel;
    private JButton startButton;

    public ModuloGUI() {
        setTitle("Modulo Operation");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        tableModel = new DefaultTableModel(new Object[]{"Value"}, 0);
        table = new JTable(tableModel);

        startButton = new JButton("Start Modulo");
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performModuloOperation();
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);

        JPanel panel = new JPanel();
        panel.add(scrollPane);
        panel.add(startButton);

        add(panel);
    }

    private void performModuloOperation() {
        int rowCount = tableModel.getRowCount();

        if (rowCount > 0) {
            // Ambil nilai awal dari tabel
            int result = Integer.parseInt(tableModel.getValueAt(0, 0).toString());

            // Lakukan operasi MOD sebanyak 10 kali dengan nilai selanjutnya di tabel
            for (int i = 1; i <= 10; i++) {
                int value = Integer.parseInt(tableModel.getValueAt(i % rowCount, 0).toString());
                result = result % value;
            }

            // Tampilkan hasil operasi MOD
            JOptionPane.showMessageDialog(this, "Hasil Operasi MOD: " + result);
        } else {
            JOptionPane.showMessageDialog(this, "Tabel kosong. Tambahkan nilai terlebih dahulu.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                ModuloGUI gui = new ModuloGUI();
                gui.setVisible(true);
            }
        });
    }
}
