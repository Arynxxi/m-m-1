import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RowSumTableApp extends JFrame {
    private DefaultTableModel tableModel;
    private JTable dataTable;
    private JButton calculateButton;

    public RowSumTableApp() {
        setTitle("Row Sum Table");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create the table with default model
        tableModel = new DefaultTableModel();
        dataTable = new JTable(tableModel);

        // Add columns to the table
        tableModel.addColumn("Column 1");
        tableModel.addColumn("Column 2");
        tableModel.addColumn("Column 3");
        tableModel.addColumn("Row Sum"); // Additional column for the row sum

        // Add rows with empty data
        for (int i = 0; i < 3; i++) {
            tableModel.addRow(new Object[]{"100", "100", "100", ""});
        }

        // Create a button to calculate row sum
        calculateButton = new JButton("Calculate Row Sum");
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateRowSum();
            }
        });

        // Add components to the frame
        JScrollPane scrollPane = new JScrollPane(dataTable);
        add(scrollPane, BorderLayout.CENTER);
        add(calculateButton, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
    }

    private void calculateRowSum() {
        int rowCount = tableModel.getRowCount();
        int columnCount = tableModel.getColumnCount();

        for (int row = 0; row < rowCount; row++) {
            double sum = 0;

            for (int col = 0; col < columnCount - 1; col++) {
                Object cellValue = tableModel.getValueAt(row, col);
                if (cellValue instanceof Number) {
                    sum += ((Number) cellValue).doubleValue();
                }
            }

            tableModel.setValueAt(sum, row, columnCount - 1);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new RowSumTableApp().setVisible(true);
            }
        });
    }
}
