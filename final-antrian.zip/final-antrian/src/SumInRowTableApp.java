import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SumInRowTableApp extends JFrame {
    private DefaultTableModel tableModel;
    private JTable dataTable;
    private JButton addButton;

    public SumInRowTableApp() {
        setTitle("Sum in Row Table");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create the table with default model
        tableModel = new DefaultTableModel();
        dataTable = new JTable(tableModel);

        // Add columns to the table
        tableModel.addColumn("Column 1");
        tableModel.addColumn("Column 2");
        tableModel.addColumn("Column 3");
        tableModel.addColumn("Total"); // Additional column for the sum

        // Add rows with empty data
        for (int i = 0; i < 3; i++) {
            tableModel.addRow(new Object[]{"", "", "", ""});
        }

        // Create a button to add a new row
        addButton = new JButton("Add Row");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNewRow();
            }
        });

        // Add components to the frame
        JScrollPane scrollPane = new JScrollPane(dataTable);
        add(scrollPane, BorderLayout.CENTER);
        add(addButton, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
    }

    private void addNewRow() {
        tableModel.addRow(new Object[]{"", "", "", ""});
    }

    private void calculateRowSum(int rowIndex) {
        int columnCount = tableModel.getColumnCount();
        double sum = 0;

        for (int col = 0; col < columnCount - 1; col++) {
            Object cellValue = tableModel.getValueAt(rowIndex, col);
            if (cellValue instanceof Number) {
                sum += ((Number) cellValue).doubleValue();
            }
        }

        tableModel.setValueAt(sum, rowIndex, columnCount - 1);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SumInRowTableApp().setVisible(true);
            }
        });
    }
}
